Please note that in exercise files attachment, there are two files as follows: 
-  09-09-2020 : This contains COVID-19 data as of 09-Sep across the globe 
(Note: Source of data :https://github.com/CSSEGISandData/COVID-19) 
- Continent_Country_Mapping : This file contains continent country mapping 
(Note: Accuracy of this file cannot be determined and it might contain some errors) 
